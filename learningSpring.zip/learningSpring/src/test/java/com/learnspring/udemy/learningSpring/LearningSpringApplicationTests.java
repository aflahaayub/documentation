package com.learnspring.udemy.learningSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
